clear all 
buildmodel

%% Simulation Configuration

abstol = 1e-25;
reltol = 1e-13;
runtime = 2e8;
timeunits = 'second';

conf = lida.config;

set(conf, 'solvertype','ode15s');
set(conf.solveroptions, 'absolutetolerance',abstol);
set(conf.solveroptions, 'relativetolerance',reltol);
set(conf, 'timeunits',timeunits);

set(conf, 'stoptime',runtime);
sbioaccelerate(lida);

%% Rates Exploration 1

exp1.name = 'kf_2d';
exp1.min  = 6;  %2eX
exp1.max  = 13; %2eX
exp1.num  = 40;

exp2.name = 'kf_3d';
exp2.min  = 6; %2eX
exp2.max  = 8; %2eX
exp2.num  = 40;

outputs = {'Nl'};
runtime = 2e10;
tic
data = FUNZ.explore_duplexequalized(lida, exp1, exp2, outputs, runtime);
toc
FUNZ.logallmaxsurf(data,exp1,exp2);


%% Single run Variant
i = 1
peaktime = zeros(1,2);
for kbd = [0.02, 2e2]
v1.content = {{'parameter','kf_lig','value',0.02}...
              {'parameter','kb_duplex','value',kbd}};
var = (sbiosimulate(lida,v1));
sbioplot(var);
peaktime(:,i) = FUNZ.peakplot(var,12);
FUNZ.variantlegend(v1)
i = i + 1; 
end
%% Surface Variant Exploration 1

v1.content = {{'parameter','kf_lig','value',0.002}...
              {'parameter','kb_duplex','value',0.03}...
              {'parameter','kb_oligo_bulk','value',2}};

exp1.name = 'kf_2d';
%logspaced
exp1.min  = 7;
exp1.max  = 12;
exp1.num  = 40;

exp2.name = 'kb_oligo_surf';
%logspaced
exp2.min  = 0;
exp2.max  = 5;
exp2.num  = 40;

outputs = {'Nl'};
runtime = 2e13;
tic
data = FUNZ.explore_duplexequalized(lida, v1, exp1, exp2, outputs, runtime);
toc

hold on
figure(1)
FUNZ.logallmaxsurf(data,exp1,exp2);
FUNZ.variantlegend(v1.content)

%% Surface Variant Exploration 2

v1.content = {{'parameter','kf_lig','value',0.02}...
              {'parameter','kb_duplex','value',3e1}...
              {'parameter','kb_oligo_bulk','value',2}};

exp1.name = 'kf_2d';
%logspaced
exp1.min  = 7;
exp1.max  = 12;
exp1.num  = 40;

exp2.name = 'kf_mix';
%logspaced
exp2.min  = 6;
exp2.max  = 8;
exp2.num  = 40;

outputs = {'Nl'};
runtime = 2e12;
tic
data = FUNZ.explore_duplexbulkequalized(lida, v1, exp1, exp2, outputs, runtime);
toc
hold on
figure(2)
FUNZ.logallmaxsurf(data,exp1,exp2);
FUNZ.variantlegend(v1.content)

%% Surface Variant Exploration 3

v1.content = {{'parameter','kf_2d','value',2e11}...
              {'parameter','kf_2d_duplex','value',2e11}...
              {'parameter','kf_3d','value',2e7}...
              {'parameter','kf_mix','value',2e8}};

exp1.name = 'kf_lig';
%logspaced
exp1.min  = -4;
exp1.max  = -1;
exp1.num  = 40;

exp2.name = 'kb_duplex';
%logspaced
exp2.min  = -3;
exp2.max  = 3;
exp2.num  = 40;

outputs = {'Nl'};
runtime = 2e12;
tic
data = FUNZ.explore_duplexbulkequalized(lida, v1, exp1, exp2, outputs, runtime);
toc

hold on
figure(3)
FUNZ.logallmaxsurf(data,exp1,exp2);
FUNZ.variantlegend(v1.content)



%% exp1
runtime = 2e7;
paramnames = {'kf_2d' 'kf_2d_duplex' 'kb_duplex'};
paramvalue = [2e7 2e7 2e2];
figure(1)
hold on
FUNZ.pointexplore(lida,paramnames,paramvalue,species_names,runtime);
legend(species_names);
% FUNZ.peakplot(point,12);
title('kf2dexplore');

%% exp2
paramnames = {'kf_2d' 'kf_2d_duplex' 'kf_3d' 'kf_mix' 'kb_oligo_surf' 'kb_oligo_bulk' 'kb_duplex' 'kf_lig'};
paramvalue = [1.5e12     1.5e12       2e7      2e7      7e5            1.5e2            3e-1        2e-2  ];
figure(2)
hold on
FUNZ.pointexplore(lida,paramnames,paramvalue,species_names,2e5);
legend(species_names);
% FUNZ.peakplot(point,12);
title('ratio 2d 3d explore');


%% cursor variant

cursorvar.content = {{'parameter','kf_2d','value',cursor2.Position(1)},...
                     {'parameter','kb_oligo_surf','value',cursor2.Position(2)},...
                     {'parameter','kf_lig','value',0.02}...
                     {'parameter','kb_duplex','value',0.03}...
                     {'parameter','kb_oligo_bulk','value',2}}

set(lida.config,'stoptime',2e3);
cursordata = sbiosimulate(lida,cursorvar)
sbioplot(cursordata)
cursorpeaktime = FUNZ.peakplot(cursordata,12)




















% 
% %% explore set -- old
% if kset == "explore"
% paramnames = {'kf_duplex' 'kb_duplex'};
% paramvalue = [2e7 2e2];
% point = FUNZ.pointexplore(lida,paramnames,paramvalue,species_names,2e8);
% FUNZ.peakplot(point,12)
% end
% 
% 
% 

% kf_d = lida.reactions(6).kineticlaw.parameters(2).value;
% kb_d = lida.reactions(6).kineticlaw.parameters(1).value;
% k_lig = lida.reactions(5).kineticlaw.parameters(1).value;
% nl = SD.Data(end,5);
% nr = SD.Data(end,12);
% Tl = SD.Data(end,1);
% Tr = SD.Data(end,7);
% D = SD.Data(end,13);
% 
% KED = (kf_d/kb_d) + (k_lig/kb_d)*((nl+nr)/(Tl*Tr));
% KEDDDD = D / (Tl*Tr);
% Kminus = kf_d + k_lig*((nl+nr)/(Tl*Tr));
% 
% tau = (k_lig*y0_olig);
% 