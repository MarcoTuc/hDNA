buildmodel.m:
this scripts implements all the routines needed for simbiology to build a 
model representing LIDA. Here initial concentrations are defined inside 
%%speciesroutine section. A Stochiometric matrix helps the code know who
reacts with who so that we can just use the information contained in there
to build everything automatically. In the end two variant objects are 
created which are useful for model exploration. 

FUNZ.m:
just a wrapper class for all the functions to be called as 
FUNZ.[functionname](arguments) 

modelexplore.m: 
here various surfaces are plotted, this script calls buildmodel before
doing anything else. 

rate_constants.m: 
here various rateconstant sets are written down, right now there are three: 
'realistic' with backward rates taken from free energy data about strands
'exploration' a set in which we can vary all parameters independently
'mix' a set in which the parameters set is reduced to few ones that
control many reactions at once. this is the one I'm currently using to
build surfaces 