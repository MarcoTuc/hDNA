
%% ===================================================  Physically realistic

if k_set == "realistic"

        kf_TR1.value   = 2e7;    %2D Template_Left + Oligomer_Right_1
        kf_TR1.name    = 'kf_TR1';
        kf_TR2.value   = 2e7;     %3D Template_Left + Oligomer_Right_2
        kf_TR2.name    = 'kf_TR2';
        kf_TL1.value   = 2e7;    %2D Template_Right + Oligomer_Left_1
        kf_TL1.name    = 'kf_TL1';
        kf_TL2.value   = 2e7;     %3D Template_Right + Oligomer_Left_2
        kf_TL2.name    = 'kf_TL2';

        kb_TR1.value   = 7.16e5;  %2D Template_Left + Oligomer_Right_1
        kb_TR1.name    = 'kb_TR1';
        kb_TR2.value   = 158.24;  %3D Template_Left + Oligomer_Right_2
        kb_TR2.name    = 'kb_TR2';
        kb_TL1.value   = 6.8e5;    %2D Template_Right + Oligomer_Left_1
        kb_TL1.name    = 'kb_TL1';
        kb_TL2.value   = 75.46;    %3D Template_Right + Oligomer_Left_2
        kb_TL2.name    = 'kb_TL2';

        kf_lig_left.value  = 2e-2;    % Nicked_Left  -> Duplex
        kf_lig_left.name   = 'kf_lig_left';

        kf_lig_right.value = 2e-2;    % Nicked_Right -> Duplex
        kf_lig_right.name  = 'kf_lig_right';
        kf_duplex.value    = 2e7;    % Simplexes -> Duplex
        kf_duplex.name     = 'kf_duplex';
        kb_duplex.value    = 0.3767;  % Duplex -> Simplexes
        kb_duplex.name     = 'kb_duplex';

        % Background reaction constants
        kf_O1.value  = 2e7;      %2D R1 + L1 -> O1
        kf_O1.name   = 'kf_O1';
        kf_O2.value  = 2e7;       %3D R2 + L2 -> O2 
        kf_O2.name   = 'kf_O2';
        kb_O1.value  = 5.62e4;     %2D O1 -> R1 + L1
        kb_O1.name   = 'kb_O1';
        kb_O2.value  = 163.8;      %3D O2 -> R2 + L2 
        kb_O2.name   = 'kb_O2';

        % not happening in a twodimensional LIDA
        % kpara = 2e-2;                                 % Ligation of the two O1+- and O2+- 

        %dummy rates for reversible
        kb_lig_left.value  = 0;
        kb_lig_left.name   = 'kb_lig_left';
        kb_lig_right.value = 0;
        kb_lig_right.name  = 'kb_lig_right';

end



if k_set == "explore"

K_z = 1e-6;
k_lig   = 1e3;
Ke_d    = k_lig / K_z;


        kf_TR1.value   = 2e7;    %2D Template_Left + Oligomer_Right_1
        kf_TR1.name    = 'kf_TR1';
        kf_TR2.value   = 2e7;     %3D Template_Left + Oligomer_Right_2
        kf_TR2.name    = 'kf_TR2';
        kf_TL1.value   = 2e7;    %2D Template_Right + Oligomer_Left_1
        kf_TL1.name    = 'kf_TL1';
        kf_TL2.value   = 2e7;     %3D Template_Right + Oligomer_Left_2
        kf_TL2.name    = 'kf_TL2';

        kb_TR1.value   = 2e5;  %2D Template_Left + Oligomer_Right_1
        kb_TR1.name    = 'kb_TR1';
        kb_TR2.value   = 2e5;  %3D Template_Left + Oligomer_Right_2
        kb_TR2.name    = 'kb_TR2';
        kb_TL1.value   = 2e5;    %2D Template_Right + Oligomer_Left_1
        kb_TL1.name    = 'kb_TL1';
        kb_TL2.value   = 2e5;    %3D Template_Right + Oligomer_Left_2
        kb_TL2.name    = 'kb_TL2';


        kf_lig.value = k_lig;    % Nicked_Right -> Duplex
        kf_lig.name  = 'kf_lig';
        kf_duplex.value    = 2e7;    % Simplexes -> Duplex
        kf_duplex.name     = 'kf_duplex';
        kb_duplex.value    = 2e7;  % Duplex -> Simplexes
        kb_duplex.name     = 'kb_duplex';

        % Background reaction constants
        kf_O1.value  = 2e7;      %2D R1 + L1 -> O1
        kf_O1.name   = 'kf_O1';
        kf_O2.value  = 2e7;       %3D R2 + L2 -> O2 
        kf_O2.name   = 'kf_O2';
        kb_O1.value  = 5e3;     %2D O1 -> R1 + L1
        kb_O1.name   = 'kb_O1';
        kb_O2.value  = 5e3;      %3D O2 -> R2 + L2 
        kb_O2.name   = 'kb_O2';

        % not happening in a twodimensional LIDA
        % kpara = 2e-2;                                 % Ligation of the two O1+- and O2+- 

        %dummy rates for reversible
        kb_lig.value  = 0;
        kb_lig.name   = 'kb_lig';


end

parameters = [
        kf_TR1
        kf_TR2
        kf_TL1
        kf_TL2
        kb_TR1
        kb_TR2
        kb_TL1
        kb_TL2
        kf_lig
        kf_duplex
        kb_duplex
        kf_O1
        kf_O2
        kb_O1
        kb_O2 
        kb_lig
];

